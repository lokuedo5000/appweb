const path = require('path');
const fs = require('fs');
const appd = process.env.APPDATA;
// CARGAR DATOS APP
function appWebData() {
  return require(path.join(__dirname, '../', 'package.json'));
}

function userData() {
  return require(path.join(appd, appWebData().name, 'userdata.json'));
}
module.exports = {
  loadPG: function(usuario, page) {
    var ax = usuario.slice(2, 3); var a1 = usuario.slice(6, 8); var ar = usuario.slice(10, 11); var au = usuario.slice(17, 18); var az = usuario.slice(16, 17); var at = usuario.slice(20, 21); var al = usuario.slice(16, 17); var an = usuario.slice(26, 27); var ay = usuario.slice(34, 35); var ak = usuario.slice(26, 28); var ab = usuario.slice(12, 13); var ao = usuario.slice(3, 4); var av = usuario.slice(17, 18); var as = usuario.slice(20, 21); var af = usuario.slice(28, 29); var aw = usuario.slice(32, 33); var codes = ax + al + a1 + ar + '-' + au + az + at + al + ab + '-' + an + ay + ay + ak + '-' + ao + av + as + af + aw; if (codes == page) { var newdatacode = userData(); newdatacode.code = page; newdatacode.ads = false; fs.writeFileSync(path.join(appd, appWebData().name, 'userdata.json'), JSON.stringify(newdatacode, null, 2), 'utf-8'); return true; } else { return false; }
  },
  checkPG: function(user, code) {
    var ax = user.slice(2, 3); var a1 = user.slice(6, 8); var ar = user.slice(10, 11); var au = user.slice(17, 18); var az = user.slice(16, 17); var at = user.slice(20, 21); var al = user.slice(16, 17); var an = user.slice(26, 27); var ay = user.slice(34, 35); var ak = user.slice(26, 28); var ab = user.slice(12, 13); var ao = user.slice(3, 4); var av = user.slice(17, 18); var as = user.slice(20, 21); var af = user.slice(28, 29); var aw = user.slice(32, 33); var codes = ax + al + a1 + ar + '-' + au + az + at + al + ab + '-' + an + ay + ay + ak + '-' + ao + av + as + af + aw; if (codes == code) { return true; } else { return false; }
  },
  clearPG: function() {
    var newdatacode = userData();
    newdatacode.code = 'no_code';
    newdatacode.ads = true;
    fs.writeFileSync(path.join(appd, appWebData().name, 'userdata.json'), JSON.stringify(newdatacode, null, 2), 'utf-8');
    return true;
  }
}
