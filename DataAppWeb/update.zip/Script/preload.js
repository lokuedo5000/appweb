const {
  ipcRenderer,
  shell
} = require('electron');
const path = require('path');
const fs = require('fs');
const {
  v4: uuidv4
} = require('uuid');
const getdate = require(path.join(__dirname, '../', 'appweb_modules', 'get_date'));
// DOM
window.addEventListener('DOMContentLoaded', () => {

  // SET LUGAR LINK
  document.querySelector("body").setAttribute('data-link', 'electron');

  // CARGAR USER DEFAULT
  function userdfData() {
    return require(path.join(__dirname, '../', 'data', 'userdefault.json'));
  }
  // VER LUGAR
  var ifnew = document.querySelector("body").getAttribute('data-new');
  if (ifnew == "new") {
    // SET ID
    document.querySelector(".theurls").value = uuidv4().slice(0, 8);
    // SET DEFAULT
    document.querySelector("input[name=usuario]").value = userdfData().user;
    document.querySelector("input[name=imagenUser]").value = userdfData().imguser;
    document.querySelector("input[name=facebook]").value = userdfData().facebook;
    document.querySelector("input[name=twitter]").value = userdfData().twitter;
    document.querySelector("input[name=youtube]").value = userdfData().youtube;
    document.querySelector("input[name=github]").value = userdfData().github;
    document.querySelector("input[name=origen]").value = userdfData().WebOrigen;

    // SAVE
    // GET FORM
    const formSerialize = formElement => {
      const values = {};
      const inputs = formElement.elements;

      for (let i = 0; i < inputs.length; i++) {
        values[inputs[i].name] = inputs[i].value;
      }
      return values;
    }

    var form = document.querySelector('.newart');

    var r = formSerialize(form);

    // SAVE ART
    ipcRenderer.on('app-ruta-json', (e, data) => {
      var ruta_json_temp = path.join(__dirname, '../', 'data', 'temp', 'articles_temp.json');
      var file_arts = fs.readFileSync(data, 'utf-8');
      var data_file = JSON.parse(file_arts);
      var r = formSerialize(form);

      var num = parseInt(data_file.articles.length) + parseInt(1);
      r.id = num;
      r.fecha = getdate.dateES();

      // REMPLAZAR
      var dcpRe = r.dcp;
      var eRequiMin = r.RequiMin;
      var eRequiMax = r.RequiMax;

      r.dcp = rePlaceAll(dcpRe);
      r.RequiMin = rePlaceAll(eRequiMin);
      r.RequiMax = rePlaceAll(eRequiMax);



      var sprt = '';
      if (data_file.articles.length > 0) {
        var sprt = ',';
      }

      var otros = data_file.articles;
      fs.writeFileSync(ruta_json_temp, JSON.stringify(otros, null, 2), 'utf-8');


      var leerTemp = fs.readFileSync(ruta_json_temp, 'utf-8');

      var leerTemp = leerTemp.replace(/\[/g, '').replace(/\]/g, '');
      var newadd = JSON.stringify(r, null, 2);
      fs.writeFileSync(ruta_json_temp, '[' + newadd + sprt + leerTemp + ']', 'utf-8');

      var leerTemp_is_save = fs.readFileSync(ruta_json_temp, 'utf-8');

      var setadd = JSON.parse(leerTemp_is_save);

      data_file.articles = setadd;

      fs.writeFileSync(data, JSON.stringify(data_file, null, 0), 'utf-8');





    })

  }else if (ifnew == "editar") {

    // SAVE
    // GET FORM
    const formSerialize = formElement => {
      const values = {};
      const inputs = formElement.elements;

      for (let i = 0; i < inputs.length; i++) {
        values[inputs[i].name] = inputs[i].value;
      }
      return values;
    }

    var form = document.querySelector('.newart');

    var r = formSerialize(form);

    // SAVE ART
    ipcRenderer.on('app-ruta-json', (e, data) => {
      var ruta_json_temp = path.join(__dirname, '../', 'data', 'temp', 'articles_temp.json');
      var file_arts = fs.readFileSync(data, 'utf-8');
      var data_file = JSON.parse(file_arts);
      var r = formSerialize(form);

      for (var g = 0; g < data_file.articles.length; g++){
        if (data_file.articles[g].urls == r.urls) {
          data_file.articles[g].urls = r.urls;
          data_file.articles[g].origen = r.origen;
          data_file.articles[g].tipo = r.tipo;
          data_file.articles[g].estado = r.estado;
          data_file.articles[g].name = r.name;
          data_file.articles[g].desarrolladora = r.desarrolladora;
          data_file.articles[g].video = r.video;
          data_file.articles[g].img = r.img;
          data_file.articles[g].banner = r.banner;
          data_file.articles[g].servidor = r.servidor;
          data_file.articles[g].peso = r.peso;
          data_file.articles[g].version = r.version;
          data_file.articles[g].extension = r.extension;
          data_file.articles[g].generos = r.generos;
          data_file.articles[g].tags = r.tags;
          data_file.articles[g].dcp = rePlaceAll(r.dcp);
          data_file.articles[g].RequiMin = rePlaceAll(r.RequiMin);
          data_file.articles[g].RequiMax = rePlaceAll(r.RequiMax);
          data_file.articles[g].enlaces = r.enlaces;
          data_file.articles[g].password = r.password;
          data_file.articles[g].usuario = r.usuario;
          data_file.articles[g].imagenUser = r.imagenUser;
          data_file.articles[g].facebook = r.facebook;
          data_file.articles[g].twitter = r.twitter;
          data_file.articles[g].youtube = r.youtube;
          data_file.articles[g].github = r.github;
          data_file.articles[g].fecha = "Update - "+getdate.dateES();
          break;
        }
      }

      // console.log(data_file);
      fs.writeFile(data, JSON.stringify(data_file, null, 2), function writeJSON(err) {
        if (err) return console.log(err);

        location.reload();

      });



    })

  }


  function rePlaceAll(text) {
    return text.replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/'/g, '&#39;');
  }




  // OPEN LINKS
  let urls = document.querySelectorAll('.linkall');
  urls.forEach(link => {
    link.addEventListener('click', () => {
      var linkWeb = link.getAttribute("data-url");
      if (linkWeb == 'no') {
        return false;
      } else {
        event.preventDefault();
        shell.openExternal(linkWeb);
      }
    })
  })


  // CARGAR DATOS APP
  function appWebData() {
    return require(path.join(__dirname, '../', 'package.json'));
  }

  function versionData() {
    return require(path.join(__dirname, '../', 'data', 'version', 'version.json'));
  }

  if (versionData().vCode > appWebData().vCode) {
    let createvideo = document.querySelector('body');
    var bntup = document.createElement("div");
    bntup.setAttribute("class", 'btn-floating btn-large pulse posiup clickupd');
    bntup.innerHTML = "<i class='cwI-cloud-download1'></i>";
    createvideo.appendChild(bntup);
  }

  let createvideo = document.querySelector('body');
  var bntup = document.createElement("div");
  bntup.setAttribute("class", 'd-none clickupd');
  bntup.innerHTML = "<i class='cwI-cloud-download1'></i>";
  createvideo.appendChild(bntup);

  const clickupd = document.querySelector(".clickupd");
  // Agregar listener
  clickupd.addEventListener("click", function(evento) {
    clearUpdate()
    var newCode = appWebData();
    newCode.vCode = versionData().vCode;
    newCode.urlUpdate = versionData().url;
    fs.writeFileSync(path.join(__dirname, '../', 'package.json'), JSON.stringify(newCode, null, 2), 'utf-8');
    ipcRenderer.send('app--update', 'false');
  })

  function clearUpdate() {
    var lista = document.querySelector("body");
    var item = lista.querySelector('.posiup');
    lista.removeChild(item);
  }


})
