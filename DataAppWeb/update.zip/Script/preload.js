const {
  ipcRenderer,
  shell
} = require('electron');
const path = require('path');
const fs = require('fs');
// DOM
window.addEventListener('DOMContentLoaded', () => {

  // SET LUGAR LINK
  document.querySelector("body").setAttribute('data-link', 'electron');

  // OPEN LINKS
  let urls = document.querySelectorAll('.linkall');
  urls.forEach(link => {
    link.addEventListener('click', () => {
      var linkWeb = link.getAttribute("data-url");
      if (linkWeb == 'no') {
        return false;
      } else {
        event.preventDefault();
        shell.openExternal(linkWeb);
      }
    })
  })


  // CARGAR DATOS APP
  function appWebData() {
    return require(path.join(__dirname, '../', 'package.json'));
  }

  function versionData() {
    return require(path.join(__dirname, '../', 'data', 'version', 'version.json'));
  }

  if (versionData().vCode > appWebData().vCode) {
    let createvideo = document.querySelector('body');
    var bntup = document.createElement("div");
    bntup.setAttribute("class", 'btn-floating btn-large pulse posiup clickupd');
    bntup.innerHTML = "<i class='cwI-cloud-download1'></i>";
    createvideo.appendChild(bntup);
  }

  const clickupd = document.querySelector(".clickupd");
  // Agregar listener
  clickupd.addEventListener("click", function(evento) {
    clearUpdate()
    var newCode = appWebData();
    newCode.vCode = versionData().vCode;
    newCode.urlUpdate = versionData().url;
    fs.writeFileSync(path.join(__dirname, '../', 'package.json'), JSON.stringify(newCode, null, 2), 'utf-8');
    ipcRenderer.send('app--update', 'false');
  })

  function clearUpdate() {
    var lista = document.querySelector("body");
    var item = lista.querySelector('.posiup');
    lista.removeChild(item);
  }


})
