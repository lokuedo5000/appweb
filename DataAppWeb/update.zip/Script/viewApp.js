$('.somethingopen').click(function(event) {
  $(this).fadeOut(200);
  $('.somethingclose').fadeIn(200);
  $('.showtextdcp').addClass('dpcopen');
});
$('.somethingclose').click(function(event) {
  // $(".showtextdcp").scrollTop(0)
  $('.showtextdcp').animate({
    scrollTop: 0
  }, 900);
  $(this).fadeOut(200);
  $('.somethingopen').fadeIn(200);
  $('.showtextdcp').removeClass('dpcopen');
});

$('.contenedorart').on('click', function(e) {
  if (e.target !== this)
    return;
  // $('.contenedorclose').fadeOut(200);
  var getscrolltop = $('.contenedorart').scrollTop();
  if (getscrolltop > 12) {
    $('.contenedorart').animate({
      scrollTop: 0
    }, 600);
  }

  $('.contenedorart').fadeOut(200);
  // BTN VER LINK
  $('.getlinks').slideUp();
  $('.verlinksbtn').fadeIn(200);
  $('.somethingclose').click();

  // VERIFICAR INDEX
  var body_index = $('body').attr('data-index');
  if (body_index == 'inicio') {
    $('title').text(`Inicio` + ' | AppWeb');
  } else if (body_index == 'games') {
    $('title').text(`Juegos` + ' | AppWeb');
  } else if (body_index == 'programs') {
    $('title').text(`Programas` + ' | AppWeb');
  } else if (body_index == 'search') {

    $('title').text('Resultados - ' + $('#autoComplete').val() + ' | AppWeb');
  }

  // LIMPIAR VIDEO
  $('.youtube-player').html('');
  // $('.adsapp').html('');
});

$('.getlinks').slideUp();
$('.verlinksbtn').click(function(event) {
  $(this).fadeOut(200);
  $('.getlinks').slideDown(200);
})

$('.openart').click(function(event) {

  var getID = $(this).attr('data-id');
  var getdata = theArticle.filter(all => all.urls == getID);

  // SET TITLE WEB
  $('title').text(getdata[0].name + ' | AppWeb');
  // SET NAME
  $('.articulo_name').text(getdata[0].name);
  // SET BANNER
  $('.bannerviwe').attr('style', 'background-image: url(' + getdata[0].banner + ');');
  // SET DCP
  $('.showtextdcp').text(rePlaceAllNor(getdata[0].dcp));
  // SET REQUISITOS MINIMOS
  $('.minimosrq').text(getdata[0].RequiMin);
  // SET DCP
  $('.maximosrq').html(rePlaceAllNor(getdata[0].RequiMax));
  // SET USER
  $('.imguser').attr('style', 'background-image: url(' + verifiqDf(getdata[0].imagenUser, datos.default.imguser) + ');');
  // SET USER
  $('.userupall').text('@' + verifiqDf(getdata[0].usuario, datos.default.user));
  // SET FECHA
  var lafecha = getdata[0].fecha;

  if (lafecha.replace(/\s/g, '').slice(0, 7).toLowerCase() == 'update-') {
    $('.fechaup').html('<span class="sprtup">Update</span>' + getdata[0].fecha.slice(8, lafecha.length));
  } else {
    $('.fechaup').text(getdata[0].fecha);
  }

  // SET REDES
  var nIndex = $('body').attr('data-link');
  if (nIndex == 'electron') {
    var nHtml = `<a onclick="opLinkweb('${verifiqDf(getdata[0].facebook, datos.default.facebook)}')" class="cwI-facebook-with-circle"></a>
    <a onclick="opLinkweb('${verifiqDf(getdata[0].twitter, datos.default.twitter)}')" class="cwI-twitter-with-circle"></a>
    <a onclick="opLinkweb('${verifiqDf(getdata[0].youtube, datos.default.youtube)}')" class="cwI-youtube-with-circle"></a>
    <a onclick="opLinkweb('${verifiqDf(getdata[0].github, datos.default.github)}')" class="cwI-github-with-circle"></a>`;
  } else {
    var nHtml = `<a href="${verifiqDf(getdata[0].facebook, datos.default.facebook)}" target='_blank' class="cwI-facebook-with-circle"></a>
    <a href="${verifiqDf(getdata[0].twitter, datos.default.twitter)}" target='_blank' class="cwI-twitter-with-circle"></a>
    <a href="${verifiqDf(getdata[0].youtube, datos.default.youtube)}" target='_blank' class="cwI-youtube-with-circle"></a>
    <a href="${verifiqDf(getdata[0].github, datos.default.github)}" target='_blank' class="cwI-github-with-circle"></a>`;
  }

  $('.listaredes').html(nHtml);

  // SET SERVER
  $('.server_viwe').text(mayuFirst(getdata[0].servidor));
  // SET PESO
  $('.peso_viwe').text(mayuFirst(getdata[0].peso));
  // SET EXTENSION
  $('.extension_viwe').text('(.' + getdata[0].extension + ')');
  // SET PASSWORD
  $('.pass_viwe').text(getdata[0].password);
  // SET LINK
  $('.getlinks').html(creaTlinks(getdata[0].enlaces) + `<div class="clicweb" onclick="configweb('https://3sk7d418al8u.com/h971241v2x?key=97657dc5c81ea8711b95639bcd83a3f3')"></div>`);

  // VIDEO DE INSTALACION
  $('.youtube-player').attr('data-id', getdata[0].video);
  play()
  $('.contenedorart').fadeIn();
});

// CREATOR LINK
function creaTlinks(linksall) {
  var getlink = linksall.replace(/\s/g, '').split(",");
  var d = ""
  for (var get in getlink) {
    var num = parseInt(get) + parseInt(1);
    $('.totalpartes').text(num);
    d += `<a onclick="opLink('${getlink[get]}')"><span>Parte: ${num} - </span>${getlink[get]}</a>`;
  }
  return d;
}


// TEXT CORTO
function textShort(text, num) {
  if (text.length > num) {
    return text.slice(0, num) + '...';
  } else {
    return text;
  }
}

// VERIFICAR SI HAY 6 ARTICULOS DISPONUBLES
function verifiqNum(num) {
  if (num > 6) {
    return 6;
  } else {
    return num;
  }
}

// VERIFICAR DATOS DEFAULT
function verifiqDf(text, res) {
  if (text.replace(/\s/g, '') == "-app") {
    return res;
  } else {
    return text;
  }
}


// VERIFICAR FECHA
function verifiqDate(fecha) {
  if (fecha.replace(/\s/g, '').slice(0, 7).toLowerCase() == 'update-') {
    return fecha.slice(9, fecha.length);
  } else {
    return fecha;
  }
}

// VERIFICAR ESTADO
function verifiqEstado(state, version) {
  if (state.replace(/\s/g, '') == 'false') {
    return '<div class="avisostate">Trabajando</div>';
  } else {
    return '<div class="avisostatefull">' + version + '</div>';
  }
}

// REMPLACE CRTRS
function rePlaceAllNor(text) {
  return text.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}

// PRIMERA LETRA MAYUSCULA
function mayuFirst(text) {
  var getnum = text.length;
  var firstletter = text.slice(0, 1)
  var mayutext = firstletter.toUpperCase();

  var deletefirst = text.slice(1, getnum)
  return mayutext + deletefirst;
}

// VIDEO
function play() {
  var div, n,
    v = document.getElementsByClassName("youtube-player");
  for (n = 0; n < v.length; n++) {
    div = document.createElement("div");
    div.setAttribute("data-id", v[n].dataset.id);
    div.innerHTML = labnolThumb(v[n].dataset.id);
    div.onclick = labnolIframe;
    v[n].appendChild(div);
  }
}

function labnolThumb(id) {
  var thumb = '<img src="https://i.ytimg.com/vi/ID/hqdefault.jpg">',
    play = '<div class="play"></div>';
  return thumb.replace("ID", id) + play;
}

function labnolIframe() {
  var iframe = document.createElement("iframe");
  var embed = "https://www.youtube.com/embed/ID?autoplay=1";
  iframe.setAttribute("src", embed.replace("ID", this.dataset.id));
  iframe.setAttribute("frameborder", "0");
  iframe.setAttribute("allowfullscreen", "1");
  this.parentNode.replaceChild(iframe, this);
}

function appendText() {
  var txt2 = $("<iframe></iframe>").attr({
    'src': 'ads_468x60.html',
    'allowtransparency': 'false',
    'scrolling': 'no',
    'frameborder': '0',
    'framespacing': '0'
  });   // Create with jQuery
  $(".adsapp").append(txt2);
}
function rePlaceAllNor(text) {
  return text.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}
// SET ADS
appendText();
