$('.openart').click(function(event) {
  var getID = $(this).attr('data-id');
  var getdata = theArticle.filter(all => all.urls == getID);
  window.location.href='/download?v='+getdata[0].urls;
})

// CREATOR LINK
function creaTlinks(linksall) {
  var getlink = linksall.replace(/\s/g, '').split(",");
  var d = ""
  for (var get in getlink) {
    var num = parseInt(get) + parseInt(1);
    $('.totalpartes').text(num);
    d += `<a onclick="opLink('${getlink[get]}')"><span>Parte: ${num} - </span>${getlink[get]}</a>`;
  }
  return d;
}




// TEXT CORTO
function textShort(text, num) {
  if (text.length > num) {
    return text.slice(0, num) + '...';
  } else {
    return text;
  }
}

// VERIFICAR SI HAY 6 ARTICULOS DISPONUBLES
function verifiqNum(num) {
  if (num > 6) {
    return 6;
  } else {
    return num;
  }
}

// VERIFICAR DATOS DEFAULT
function verifiqDf(text, res) {
  if (text.replace(/\s/g, '') == "-app") {
    return res;
  } else {
    return text;
  }
}

// REMPLAZAR ESPACIOS
function spaceRem(text) {
  return text.replace(/\s/g, '-');
}

// VERIFICAR FECHA
function verifiqDate(fecha) {
  if (fecha.replace(/\s/g, '').slice(0, 7).toLowerCase() == 'update-') {
    return fecha.slice(9, fecha.length);
  } else {
    return fecha;
  }
}

// VERIFICAR ESTADO
function verifiqEstado(state, version) {
  if (state.replace(/\s/g, '') == 'false') {
    return '<div class="avisostate">Trabajando</div>';
  } else {
    return '<div class="avisostatefull">' + version + '</div>';
  }
}

// REMPLACE CRTRS
function rePlaceAllNor(text) {
  return text.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}

// PRIMERA LETRA MAYUSCULA
function mayuFirst(text) {
  var getnum = text.length;
  var firstletter = text.slice(0, 1)
  var mayutext = firstletter.toUpperCase();

  var deletefirst = text.slice(1, getnum)
  return mayutext + deletefirst;
}

// VIDEO
function play() {
  var div, n,
    v = document.getElementsByClassName("youtube-player");
  for (n = 0; n < v.length; n++) {
    div = document.createElement("div");
    div.setAttribute("data-id", v[n].dataset.id);
    div.innerHTML = labnolThumb(v[n].dataset.id);
    div.onclick = labnolIframe;
    v[n].appendChild(div);
  }
}

function labnolThumb(id) {
  var thumb = '<img src="https://i.ytimg.com/vi/ID/hqdefault.jpg">',
    play = '<div class="play"></div>';
  return thumb.replace("ID", id) + play;
}

function labnolIframe() {
  var iframe = document.createElement("iframe");
  var embed = "https://www.youtube.com/embed/ID?autoplay=1";
  iframe.setAttribute("src", embed.replace("ID", this.dataset.id));
  iframe.setAttribute("frameborder", "0");
  iframe.setAttribute("allowfullscreen", "1");
  this.parentNode.replaceChild(iframe, this);
}

function appendText() {
  var txt2 = $("<iframe></iframe>").attr({
    'src': 'ads_468x60.html',
    'allowtransparency': 'false',
    'scrolling': 'no',
    'frameborder': '0',
    'framespacing': '0'
  });   // Create with jQuery
  $(".adsapp").append(txt2);
}
function rePlaceAllNor(text) {
  return text.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}
// SET ADS
appendText();
