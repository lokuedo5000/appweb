const {
  ipcRenderer,
  shell
} = require('electron');
const path = require('path');
const fs = require('fs');
// DOM
window.addEventListener('DOMContentLoaded', () => {

  // CARGAR DATOS APP
  function appWebData() {
    return require(path.join(__dirname, '../', 'package.json'));
  }

  function versionData() {
    return require(path.join(__dirname, '../', 'data', 'version', 'version.json'));
  }

  ipcRenderer.on('app--progrees', (e, data) => {
    document.querySelector(".set_progrees").style.width = data + "%";
  })

  ipcRenderer.on('app--end', (e, data) => {
    var enfile = setInterval(function() {
      clearInterval(enfile);
      ipcRenderer.send('end_download_file_version', 'true');
    }, 3000);
  })

  window.addEventListener('load', listo, false);

  function listo() {
    var newCode = appWebData();
    newCode.urldb = versionData().urldb;
    fs.writeFileSync(path.join(__dirname, '../', 'package.json'), JSON.stringify(newCode, null, 2), 'utf-8');
    
    var settime = setInterval(function() {
      clearInterval(settime);
      ipcRenderer.send('update_file_version', 'true');
    }, 4000);
  }
})
