const {
  ipcRenderer,
  shell
} = require('electron');
// DOM
window.addEventListener('DOMContentLoaded', () => {

  ipcRenderer.on('app--progrees', (e, data) => {
    document.querySelector(".set_progrees").style.width = data+"%";
  })

  ipcRenderer.on('app--end', (e, data) => {
    var enfile = setInterval(function(){
      clearInterval(enfile);
      ipcRenderer.send('end_download_file_version', 'true');
    }, 3000);
  })

  window.addEventListener('load', listo, false);
  function listo() {
    var settime = setInterval(function(){
      clearInterval(settime);
      ipcRenderer.send('update_file_version', 'true');
    }, 4000);
  }
})
