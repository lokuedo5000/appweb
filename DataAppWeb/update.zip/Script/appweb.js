// REQUIRE JS EXPRESS
const express = require('express')
const web = express()
// REQUIRE JS EJS
const ejs = require('ejs');
// REQUIRE JS ELECTRON
const {
  app,
  BrowserWindow,
  webContents,
  Menu,
  ipcMain,
  nativeTheme,
  Notification,
  nativeImage,
  ipcRenderer,
  screen,
  dialog
} = require('electron');
// REQUIRE JS DEFAULT
const url = require('url');
const path = require('path');
const fs = require('fs');
const https = require('https');
const page = require(path.join(__dirname, 'reload'));
var exec = require('child_process').execFile;
// REQUIRE JS GENERADOR ID
const {
  v4: uuidv4
} = require('uuid');
// REQUIRE JS SAVE INFO WINDOWS
const WindowStateManager = require('electron-window-state-manager');
// RUTAS DE ARCHIVOS & FOLDERS
const rutasDB = path.join(__dirname, '../', 'db', 'AppDatas', 'db.json');
// APPDATA
const appd = process.env.APPDATA;
// VARIABLES
let win
let runweb
// SCRIPT APP

// CARGAR DATOS APP
function appWebData() {
  return require(path.join(__dirname, '../', 'package.json'));
}

function userData() {
  return require(path.join(appd, appWebData().name, 'userdata.json'));
}

function versionData() {
  return require(path.join(__dirname, '../', 'data', 'version', 'version.json'));
}

// CREAR ID
const getid = uuidv4().toUpperCase();
// CREATE USER ID
const cuerpo = {
  userid: getid,
  code: 'no_code',
  ads: true
}
fs.readFile(path.join(appd, appWebData().name, 'userdata.json'), 'utf-8', (err, data) => {
  if (err) {
    fs.writeFileSync(path.join(appd, appWebData().name, 'userdata.json'), JSON.stringify(cuerpo, null, 2), 'utf-8');
  } else {
    if (data.length < 4) {
      fs.writeFileSync(path.join(appd, appWebData().name, 'userdata.json'), JSON.stringify(cuerpo, null, 2), 'utf-8');
    }
  }
});


function setNuewDataDB() {
  // SAVE FILE JSON NEW
  var newCode = appWebData();
  newCode.urldb = versionData().urldb;
  fs.writeFileSync(path.join(__dirname, '../', 'package.json'), JSON.stringify(newCode, null, 2), 'utf-8');
}

// CREATE DEFAULT VERSION
const jsonDB = {
  vCode: '1.108',
  url: 'https://lokuedo5000.github.io/appweb/DataAppWeb/update.zip',
  urldb: 'https://lokuedo5000.github.io/appweb/AppDatas/articles.json'
}

// FILES NO EXISTE
fs.readFile(path.join(__dirname, '../', 'data', 'version', 'version.json'), 'utf-8', (err, data) => {
  if (err) {
    fs.writeFileSync(path.join(__dirname, '../', 'data', 'version', 'version.json'), JSON.stringify(jsonDB, null, 2), 'utf-8');
    setNuewDataDB();
  } else {
    if (data.length < 4) {
      fs.writeFileSync(path.join(__dirname, '../', 'data', 'version', 'version.json'), JSON.stringify(jsonDB, null, 2), 'utf-8');
    }
    setNuewDataDB();
  }
});

// CREATE DEFAULT USER
const jsonDEFAULT = {
  user: '-app',
  imguser: '-app',
  facebook: '-app',
  twitter: '-app',
  youtube: '-app',
  github: '-app',
  whatsapp: '-app',
  WebOrigen: '-app'
}

// FILES NO EXISTE
fs.readFile(path.join(__dirname, '../', 'data', 'userdefault.json'), 'utf-8', (err, data) => {
  if (err) {
    fs.writeFileSync(path.join(__dirname, '../', 'data', 'userdefault.json'), JSON.stringify(jsonDEFAULT, null, 2), 'utf-8');
  } else {
    if (data.length < 4) {
      fs.writeFileSync(path.join(__dirname, '../', 'data', 'userdefault.json'), JSON.stringify(jsonDEFAULT, null, 2), 'utf-8');
    }
  }
});

// DESCARGAR ARCHIVOS
function download(urlV, rutaIns, tipo) {
  var file = fs.createWriteStream(rutaIns);
  var len = 0;

  https.get(urlV, function(res) {
    res.on('data', function(chunk) {
      file.write(chunk);
      len += chunk.length;
      var percent = (len / res.headers['content-length']) * 100;
      if (tipo == "update_file_version") {
        win.webContents.send('app--progrees', percent);
      }
      // ipcMain.on('app--run-update', (e, data) => {})
      // var percent = (len / res.headers['content-length']) * 100;

    });

    res.on('end', function() {
      file.close();
    });
    file.on('close', function() {
      if (tipo == "update_file_version") {
        win.webContents.send('app--end', 'closefile');
      }
    });
  });
}

ipcMain.on('update_file_version', (e, data) => {
  var ruta = path.join(__dirname, '../', 'data', 'version', 'version.json');
  download(appWebData().urlVersion, ruta, 'update_file_version');
})

ipcMain.on('end_download_file_version', (e, data) => {
  endloading();
  win.close();
})

// EJECUTAR UPDATE
function execute(fileName, params, path) {
  let promise = new Promise((resolve, reject) => {
    exec(fileName, params, {
      cwd: path
    }, (err, data) => {

      if (err) reject(err);
      else {
        resolve(data);
        app.quit();
        // console.log(resolve(data));
      }

    });
  });
  return promise;
}

ipcMain.on('app--update', (e, data) => {
  global.appRoot = path.resolve(__dirname);
  fs.writeFileSync(path.join(__dirname, '../', 'data', 'AppWebUpdate', 'Data', 'Data.ini'), '[RUTAS]\nurl=' + appWebData().urlUpdate + '\ninstall=' + path.join(__dirname, '../'), 'utf-8');
  execute('AppWebUP.exe', null, path.join(__dirname, '../', 'data', 'AppWebUpdate'));
  // app.quit();
})

function viewApp() {
  return fs.readFileSync(path.join(__dirname, 'viewApp.js'), 'utf-8');
}

function textAds() {
  if (userData().ads == true) {
    return '$(".avisoadsactive").text("activada");';
  } else {
    return '$(".avisoadsactive").text("desactivada");';
  }
}

// SETTING SERVER
// SERVER
var theserver = appWebData();
web.set("view engine", "ejs");
web.set('port', theserver.serverLocal)
web.use(express.urlencoded({
  extended: false
}));


// RUTAS
// HOME
web.get('/', (req, res) => {
  var getCodeAppView = viewApp();
  var setappweb = appWebData();
  res.render(path.join(__dirname, '../', 'views', 'index'), {
    codeView: getCodeAppView,
    adsview: textAds(),
    dataus: userData(),
    dataAppWeb: setappweb
  });
})
web.get('/games', (req, res) => {
  var getCodeAppView = viewApp();
  var setappweb = appWebData();
  res.render(path.join(__dirname, '../', 'views', 'games'), {
    codeView: getCodeAppView,
    adsview: textAds(),
    dataus: userData(),
    dataAppWeb: setappweb
  });
})
web.get('/programs', (req, res) => {
  var getCodeAppView = viewApp();
  var setappweb = appWebData();
  res.render(path.join(__dirname, '../', 'views', 'programs'), {
    codeView: getCodeAppView,
    adsview: textAds(),
    dataus: userData(),
    dataAppWeb: setappweb
  });
})
web.get('/search', (req, res) => {
  var getCodeAppView = viewApp();
  var setappweb = appWebData();
  res.render(path.join(__dirname, '../', 'views', 'search'), {
    codeView: getCodeAppView,
    adsview: textAds(),
    dataus: userData(),
    dataAppWeb: setappweb
  });
})
web.get('/ads', (req, res) => {
  var getCodeAppView = userData();
  res.render(path.join(__dirname, '../', 'views', 'ads'), {
    codeView: getCodeAppView
  });
})
web.get('/download', (req, res) => {
  var getCodeAppView = viewApp();
  var setappweb = appWebData();
  res.render(path.join(__dirname, '../', 'views', 'download'), {
    codeView: getCodeAppView,
    dataus: userData(),
    adsview: textAds(),
    dataAppWeb: setappweb
  });
})
web.get('/new', (req, res) => {
  var getCodeAppView = viewApp();
  var setappweb = appWebData();
  res.render(path.join(__dirname, '../', 'views', 'new'), {
    codeView: getCodeAppView,
    dataus: userData(),
    adsview: textAds(),
    dataAppWeb: setappweb,
  });
})
// PSOT
web.post('/ads', (req, res) => {
  const {
    code
  } = req.body;
  if (page.loadPG(userData().userid, code) == true) {
    res.send('true');
  } else {
    res.send('false');
  }
})

web.post('/clearkey', (req, res) => {
  const {
    code
  } = req.body;
  if (page.clearPG() == true) {
    res.send('true');
  } else {
    res.send('false');
  }
})

web.post('/links', (req, res) => {
  const {
    links
  } = req.body;
  if (page.checkPG(userData().userid, userData().code) == true) {
    res.send(links);
  } else {
    res.send('http://adf.ly/9857561/' + links);
  }
})
// PUBLIC
web.use(express.static(path.join(__dirname, '../public')))
// CREATE SERVER

// MIDDLEWARES
web.use(function(req, res) {
  res.status(404).send('Sorry cant find that!');
})

// LISTENIG ON SERVER
web.listen(web.get('port'), () => {
  // download('https://lokuedo5000.github.io/appweb/AppDatas/articles.json', path.join(__dirname, '../', 'db', 'AppDatas', 'db.json'))
})

// SCRIPT ELECTRON
// VENTANA WEB
function endloading() {
  //DEFAULT TAMAÑO VENTANA MAINWINDOW
  const winState = new WindowStateManager('runweb', {
    defaultWidth: 506,
    defaultHeight: 500
  });

  runweb = new BrowserWindow({
    icon: path.join(__dirname, '../assets/icons/win/ico#1.ico'),
    width: winState.width,
    height: winState.height,
    'minWidth': 506,
    'minHeight': 400,
    x: winState.x,
    y: winState.y,
    title: 'AppWeb',
    // titleBarStyle: 'customButtonsOnHover',
    // transparent: true,
    // maximizable: false,
    // resizable: false,
    // frame: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  //AGREGAR MENU A MAINWINDOW
  const menuMainWindow = Menu.buildFromTemplate(templateMenu);
  runweb.setMenu(menuMainWindow);
  runweb.setMenuBarVisibility(false);

  // SI LA APLICACION SE CERRO EN MAXIMIZE
  if (winState.maximized) {
    runweb.maximize();
  }
  // CARGAR ARCHIVO LOCAL
  runweb.loadURL(appWebData().urlLocal + theserver.serverLocal);


  runweb.on('close', () => {
    winState.saveState(runweb);
    // app.quit();
  })
}
// READY
app.on('ready', () => {
  win = new BrowserWindow({
    icon: path.join(__dirname, '../assets/icons/win/ico#1.ico'),
    width: 400,
    height: 350,
    'minWidth': 400,
    'minHeight': 350,
    title: 'AppWeb',
    titleBarStyle: 'customButtonsOnHover',
    transparent: true,
    maximizable: false,
    resizable: false,
    frame: false,
    webPreferences: {
      preload: path.join(__dirname, 'update_file_version.js')
    }
  });

  //AGREGAR MENU A MAINWINDOW
  const menuMainWindow = Menu.buildFromTemplate(templateMenu);
  win.setMenu(menuMainWindow);
  win.setMenuBarVisibility(false);
  // CARGAR ARCHIVO LOCAL
  win.loadURL(path.join(__dirname, '../', 'public', 'loading.html'));


  win.on('close', () => {
    // app.quit();
  })

})

// SAVE FILES
function savefiles() {
  var options = {
    title: "Agregar",
    defaultPath: "articles.json",
    filters: [{
      name: 'Archivo',
      extensions: ['json']
    }]
  }
  dialog.showSaveDialog(null, options).then(result => {
    if (result.canceled == false) {

      const file_art = path.join(result.filePath);
      fs.readFile(file_art, 'utf-8', (err, data) => {
        if (err) {
          fs.writeFileSync(file_art, '[]', 'utf-8');
          runweb.webContents.send('app-ruta-json', result.filePath);
        }
      });

      runweb.webContents.send('app-ruta-json', result.filePath);
    }
  }).catch(err => {
    console.log(err)
  })
}



//QUITAR MENU
Menu.setApplicationMenu(null);

// Menu Template
var templateMenu = [{
  label: 'File',
  submenu: [{
      label: 'Save Json',
      accelerator: process.platform == 'darwin' ? 'command+S' : 'Ctrl+S',
      click() {
        savefiles()
      }
    },
    {
      type: 'separator'
    },
    {
      label: 'Ayuda',
      click() {

      }
    },
    {
      type: 'separator'
    },
    {
      label: 'Exit',
      accelerator: process.platform == 'darwin' ? 'command+Q' : 'Ctrl+Q',
      click() {
        app.quit();
      }
    }
  ]
}];

// Reload in Development for Browser Windows
var DevTools = process.env.APP_DEV ? (process.env.APP_DEV.trim() == "true") : true;

if (DevTools) {
  templateMenu.push({
    label: 'DevTools',
    submenu: [{
        label: 'Show/Hide Dev Tools',
        accelerator: process.platform == 'darwin' ? 'Comand+D' : 'Ctrl+D',
        click(item, focusedWindow) {
          focusedWindow.toggleDevTools();
        }
      },
      {
        role: 'reload'
      }
    ]
  })
};
