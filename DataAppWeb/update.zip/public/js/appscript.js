$.urlParam = function(name) {
  var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
  if (results == null) {
    return null;
  } else {
    return decodeURI(results[1]) || 0;
  }
}

function urlget(q) {
  return $.urlParam(q);
}

$('a.lugar').click(function(event) {
  var lugar = $(this).attr('data-lugar');
  window.location.href = '/'+lugar;
});

$(document).ready(function() {
  function gettamano() {
    var gettamano = $(window).outerWidth();
    if (gettamano > 735) {
      $('.responsi').removeAttr('style');
      $('.openmenuclose').attr('style', 'display: none;');
    }
  }
  gettamano()
  $(window).resize(function() {
    gettamano()
  });
  $(".scroll").scroll(function() {
    var sv = $(this).scrollTop();
    if (sv > 300) {
      $('.menuapp').addClass('menuappfixe');
    } else {
      $('.menuapp').removeClass('menuappfixe');
    }
  })

  $('.openmenu').click(function(event) {
    $('.menuapp .responsi').fadeIn(200);
    $('.openmenuclose').fadeIn(200);
  });
  $('.openmenuclose').click(function(event) {
    $('.openmenuclose').fadeOut();
    $('.menuapp .responsi').fadeOut();
  });
});

// const openmenu = document.querySelector(".openmenu");
// // Agregar listener
// openmenu.addEventListener("click", function(evento) {
//   let createcloseOne = document.querySelector('.menuapp');
//   var oneclose = document.createElement("div");
//   oneclose.setAttribute("class", "openmenuclose");
//   createcloseOne.appendChild(oneclose);
//
//   let createcloseTwo = document.querySelector('body');
//   var twoclose = document.createElement("div");
//   twoclose.setAttribute("class", "openmenuclose");
//   createcloseTwo.appendChild(twoclose);
// })
$('.genessearch').click(function(event) {
  var ir = $(this).attr('data-ir');
  window.location.href = '/search?v=' + ir;
});
document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("searchform").addEventListener('submit', validarFormulario);
});

function validarFormulario(evento) {
  evento.preventDefault();
  var search = document.getElementById('autoComplete').value;
  if (search.length == 0) {

    return;
  }

  this.submit();
}
