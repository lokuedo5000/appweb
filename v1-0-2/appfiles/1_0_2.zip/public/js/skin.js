// COG MENU
const menuApp = document.querySelector(".menu_app");
// STYLES
menuApp.style.background = '#e74c3c';
