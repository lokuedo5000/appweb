/*Electron JS*/
const {
  ipcRenderer,
  shell
} = require('electron');
// ID GENERATOR
const {
  v4: uuidv4
} = require('uuid');
// Default Modules
const path = require('path');
const fs = require('fs');

// Modules by lokuedo5000
var script = require(path.join(__dirname, 'web'));
const json = require(path.join(__dirname, '../../../../', 'js', 'json'));

// Torrent Parse
const parseTorrent = require('parse-torrent');
// get size
var filesize = require('file-size');

/*Dom*/
window.addEventListener('DOMContentLoaded', () => {

  // Default
  script.appcog();

  // GET FORM
  var formSerialize = formElement => {
    const values = {};
    const inputs = formElement.elements;

    for (let i = 0; i < inputs.length; i++) {
      values[inputs[i].name] = inputs[i].value;
    }
    return values;
  }

  // Save
  const savefile = document.querySelector(".savefile");
  savefile.addEventListener("click", function(evento) {
    // Donde se guarda
    var folderRuta = document.querySelector(".rutas_url_folder");

    // File
    var larutafile = document.querySelector(".rutas_url_file");

    // Verificar que la ruta no este vacia
    if (folderRuta.innerText == '{...}') {
      // Mensaje
      showtoast('Debes escoger la ruta de guardado');
    } else {
      // Obtener datos del formulario
      var form_save = document.querySelector('.infodata');
      var getForm = formSerialize(form_save);

      // Datos Torrent
      if (path.parse(larutafile.innerText).ext == '.torrent') {
        var fileget = parseTorrent(fs.readFileSync(larutafile.innerText));
      } else if (path.parse(larutafile.innerText).ext == '.awtorrent') {
        var fileget = json.read(larutafile.innerText);
      }

      // Input Value
      var getTrackerAll = document.querySelector('#announce').value.trim();

      // Eliminar saltos de lineas
      var trCrt = getTrackerAll.replace(/\s/g, ',').split(",");
      // delete
      for (var i = 0; i < trCrt.length; i++) {
        if (trCrt[i] == '') {
          trCrt.splice(i, 1);
        }
      }


      // Save Info
      json.news(path.join(folderRuta.innerText, getForm.name + '.awtorrent'), {
        infoHash: getForm.infoHash,
        name: getForm.name,
        length: parseInt(getForm.length),
        comment: getForm.comment,
        info: {
          cover: getForm.cover,
          titulo: getForm.titulo,
          video: getForm.video,
          dcp: getForm.dcp
        },
        files: fileget.files,
        announce: trCrt
      })

      // Mensaje
      showtoast('Guardado.');
    }

  })

  // Open File
  let fileopen = document.querySelectorAll('.openfile');
  fileopen.forEach(link => {
    link.addEventListener('click', () => {
      // Show Loading
      showLoading();
      if (link.getAttribute('data') == 'file') {
        // Open Rutas
        ipcRenderer.send('win-file', 'file');
      } else if (link.getAttribute('data') == 'folder') {
        // Open Rutas
        ipcRenderer.send('win-folder', 'folder');
      }
    })
  })

  // Respuesta
  ipcRenderer.on('file-open', (e, data) => {
    // Res
    if (data == 'no_file') {
      // Hide Loading
      hideLoading();
    } else {
      // boton save
      var bSave = document.querySelector(".savefile");
      bSave.classList.remove('d-none');
      // Insert File
      document.querySelector(".rutas_url_file").innerText = data;

      // Datos Torrent
      if (path.parse(data).ext == '.torrent') {
        var datos_torrent = parseTorrent(fs.readFileSync(data));
      } else if (path.parse(data).ext == '.awtorrent') {
        var datos_torrent = json.read(data);
      }

      // Script Code
      // infoHash
      document.querySelector("input[name=infoHash]").value = datos_torrent.infoHash;

      // name
      document.querySelector("input[name=name]").value = datos_torrent.name;

      // length
      document.querySelector("input[name=length]").value = datos_torrent.length;
      document.querySelector(".getpeso").innerText = filesize(datos_torrent.length).human('si');

      // comment
      var comm = datos_torrent.comment;
      if (comm == undefined) {
        var setComment = '(none)';
      } else {
        var setComment = datos_torrent.comment;
      }
      document.querySelector("input[name=comment]").value = setComment;

      // Trackers
      document.querySelector("textarea[name=announce]").value = trackers(datos_torrent.announce).trim();
      M.textareaAutoResize($('textarea[name=announce]'));

      // Lista de Archivos
      // Listas
      var listes = document.querySelector(".collection-list");
      listes.innerHTML = '';

      // Set Files
      let thefiles = datos_torrent.files;
      for (var i = 0; i < thefiles.length; i++) {
        var nameExt = path.parse(thefiles[i].name).ext;
        listes.innerHTML += `<li class="collection-item avatar" style="min-height: 50px!important;">
                                <i class="${iconos(nameExt)} circle pink"></i>
                                <span class="title">${path.parse(thefiles[i].name).name}</span>
                                <p><span class="received_des">Extension (${nameExt})</span></p>
                                <a class="secondary-content">${filesize(thefiles[i].length).human('si')}</a>
                              </li>`;
      }

      // Finished
      setTimeout(function() {
        // Hide Loading
        hideLoading();
      }, 2000);
    }
  })

  // Respuesta
  ipcRenderer.on('folder-open', (e, data) => {
    // Res
    if (data == 'no_file') {
      // Hide Loading
      hideLoading();
    } else {
      // Insert File
      document.querySelector(".rutas_url_folder").innerText = data;

      // Finished
      setTimeout(function() {
        // Hide Loading
        hideLoading();
      }, 1000);
    }
  })

  /* Action Win Minimize & Maximize => (Working) & Close*/
  let actionWin = document.querySelectorAll('.actionwin');
  actionWin.forEach(link => {
    link.addEventListener('click', () => {
      ipcRenderer.send('win-action-app', link.getAttribute('data-action'));
    })
  })

  /*Respuestas*/
  ipcRenderer.on('win-action-max-app', (e, data) => {
    if (data == 'min') {
      var maximiz = document.querySelector('.maximiz');
      maximiz.classList.remove('cwI-cheveron-up');
      maximiz.classList.add('cwI-cheveron-down');
    } else if (data == 'max') {
      var maximiz = document.querySelector('.maximiz');
      maximiz.classList.remove('cwI-cheveron-down');
      maximiz.classList.add('cwI-cheveron-up');
    }
  })

  // si se cambia manualmente el tamaño de la ventana se cambia el boton de maximizado a maximizar
  $(window).resize(function() {
    //aqui el codigo que se ejecutara cuando se redimencione la ventana
    var maximiz = document.querySelector('.maximiz');
    maximiz.classList.remove('cwI-cheveron-down');
    maximiz.classList.add('cwI-cheveron-up');
  })

  // Show Loading
  function showLoading() {
    // open loading
    var loading = document.querySelector(".loading");
    loading.classList.remove('d-none');

    // active preloader
    var preloader = document.querySelector(".preloader-wrapper");
    preloader.classList.add('active');
  }

  // Hide Loading
  function hideLoading() {
    // clear loading
    var loading = document.querySelector(".loading");
    loading.classList.add('d-none');
    // clear preloader
    var preloader = document.querySelector(".preloader-wrapper");
    preloader.classList.remove('active');
  }

  // Get Trackers
  function trackers(data) {
    var d = "";
    for (var get in data) {
      d += `${data[get]}` + '\n';
    }
    return d;
  }

  // Get Ext
  function exts(filename) {
    return filename.slice((filename.lastIndexOf(".") - 1 >>> 0) + 2);
  }

  // iconos
  function iconos(ico) {
    if (ico == '.iso') {
      var iconoFiles = 'fileext cwI-file-iso1';
    } else if (ico == '.rar') {
      var iconoFiles = 'fileext cwI-file-rar1';
    } else if (ico == '.txt') {
      var iconoFiles = 'fileext cwI-file-txt1';
    } else if (ico == '.mp4') {
      var iconoFiles = 'fileext cwI-file-mp41';
    } else if (ico == '.jpg') {
      var iconoFiles = 'fileext cwI-file-jpg1';
    } else if (ico == '.url') {
      var iconoFiles = 'cwI-link';
    } else if (ico == '.nfo') {
      var iconoFiles = 'cwI-information-solid';
    } else {
      var iconoFiles = 'cwI-plugin';
    }
    // set ico
    return iconoFiles;
  }

  // mensaje
  function showtoast(text) {
    M.toast({
      html: text
    })
  }

});
