// Default
const path = require('path');
const fs = require('fs');
const json = require(path.join(__dirname, '../../../../', 'js', 'json'));

// Datos Json
var pck = require(path.join(__dirname, 'package.json'));

// exports
module.exports = {
  appcog: function() {
    // Titulo Windows
    let title = document.querySelector('title');
    title.innerText = pck.info.title;
  }
}
