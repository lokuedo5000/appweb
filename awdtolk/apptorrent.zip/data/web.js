// Default
const path = require('path');
const fs = require('fs');
const json = require(path.join(__dirname, '../../../../', 'js', 'json'));
// get size
var filesize = require('file-size');
// WebTorrent
var WebTorrent = require('webtorrent');
const parseTorrent = require('parse-torrent');
// var client = new WebTorrent();

// Datos Json
var pck = require(path.join(__dirname, 'package.json'));
module.exports = {
  cogPage: function() {
    // Titulo Windows
    let title = document.querySelector('title');
    title.innerText = pck.info.title;
  },
  cogApp: function() {
    return pck;
  },
  update: function(file, data) {

  },
  torrent: function(tracker, data, paths) {
    // Update
    function update(file, info) {
      // load file
      const load = fs.readFileSync(file, 'utf-8');
      // json stringify
      let json = JSON.parse(load);
      // update
      for (var g = 0; g < json.length; g++) {
        if (json[g].name == info.name) {
          json[g].infoHash = info.infoHash;
          break;
        }
      }
      // save file
      fs.writeFileSync(file, JSON.stringify(json, null, 2), 'utf-8');
    }

    // Cliente
    var client = new WebTorrent();
    // Trackers
    var trackers = json.unir(tracker, data.announce);

    /* Get Uri */
    const uri = parseTorrent.toMagnetURI({
      infoHash: data.infoHash
    })

    // el Uri
    var theuri = uri + '&dn=' + data.name;

    // Download
    client.add(theuri, {
      announce: trackers,
      path: paths.folder
    }, function(torrent) {
      // create HTTP server for this torrent
      // var server = torrent.createServer()
      // server.listen('3357') // start the server listening to a port

      // toast
      showtoast('Descargando');

      /*Save Progress*/
      var interval = setInterval(function() {
        // Recivido
        var received_des = document.querySelector(".received_des");
        received_des.innerText = filesize(torrent.received).human('si');

        // Descargado
        var des_total = document.querySelector(".des_total");
        des_total.innerText = filesize(torrent.downloaded).human('si');

        // Subida
        var up_des = document.querySelector(".up_des");
        up_des.innerText = filesize(torrent.uploadSpeed).human('si');

        // Bajada
        var dow_des = document.querySelector(".dow_des");
        dow_des.innerText = filesize(torrent.downloadSpeed).human('si');

        // Progress
        var thprogress = (torrent.progress * 100).toFixed(1) + '%';

        // Progress
        var progress_app = document.querySelector(".progress_app");
        progress_app.style.width = thprogress;
        progress_app.innerText = thprogress;

        // Informacion de Torrent
        // Tiempo restante
        var timeout = document.querySelector(".timeout");
        timeout.innerText = millis2(torrent.timeRemaining);

        // Enjambre
        var enjambre = document.querySelector(".enjambre");
        enjambre.innerText = torrent.numPeers;

        // Update Hash
        update(path.join(__dirname, 'des.json'), {
          name: data.name,
          infoHash: data.infoHash
        });



        // // Per
        // var peers = document.querySelector(".verratio");
        //
        // // torrent.files.find(function(file) {
        // //   return file.name.endsWith('.mp4')
        // // })
        //
        // peers.innerHTML = torrent.numPeers;

        torrent.files.forEach(function(file) {
          var nameClass = file.name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
          // Progress
          var progressClass = document.querySelector("." + nameClass);
          progressClass.style.width = (file.progress * 100).toFixed(1) + '%';
        })

      }, 1000)

      torrent.on('done', function() {
        // Script para agregar datos al archivo des.json

        downloadend(filesize(data.length).human('si'));

        torrent.files.forEach(function(file) {
          var nameClass = file.name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
          // Progress
          var progressClass = document.querySelector("." + nameClass);
          progressClass.style.width = '100%';
        })

        // Clear of list of download
        json.clear(path.join(__dirname, 'des.json'), {
          id: data.name
        });
        // later, cleanup...
        // server.close()
        const t = client.get(data.infoHash);
        if (t) {
          t.destroy();
        }

        clearInterval(interval);
      })
    })

    // Convertir milisegundos a minutos y segundos
    function millis(millis) {
      var minutes = Math.floor(millis / 60000);
      var seconds = ((millis % 60000) / 1000).toFixed(0);
      return minutes + ":" + (seconds < 10 ? '0' : '') + seconds;
    }

    function millis2(millis) {
      let sec = Math.floor(millis / 1000);
      let hrs = Math.floor(sec / 3600);
      sec -= hrs * 3600;
      let min = Math.floor(sec / 60);
      sec -= min * 60;

      sec = '' + sec;
      sec = ('00' + sec).substring(sec.length);

      if (hrs > 0) {
        min = '' + min;
        min = ('00' + min).substring(min.length);
        return hrs + ":" + min + ":" + sec;
      } else {
        return min + ":" + sec;
      }
    }

    // fin de descarga
    function downloadend(received) {
      document.querySelector(".received_des").innerText = '0';

      // Descargado
      var des_total = document.querySelector(".des_total");
      des_total.innerText = received;

      // Subida
      document.querySelector(".up_des").innerText = '0';
      // Bajada
      document.querySelector(".dow_des").innerText = '0';
      // Progress
      var progress_app = document.querySelector(".progress_app");
      progress_app.style.width = '100%';
      progress_app.innerText = '100%';
      // Informacion de Torrent
      // Tiempo restante
      document.querySelector(".timeout").innerText = '0:00';
      // Enjambre
      document.querySelector(".enjambre").innerText = '0';

      // toast
      showtoast('Descarga Completa');

      // Active btn Stop
      let stop_des = document.querySelector(".stop_des");
      // Active btn New
      let new_des = document.querySelector(".new_des");
      // Clear btn Stop
      stop_des.classList.add('d-none');
      // Active btn New
      new_des.classList.remove('d-none');

    }

    // mensaje
    function showtoast(text) {
      M.toast({
        html: text
      })
    }
  }
}
