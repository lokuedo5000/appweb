// Default
const path = require('path');
const fs = require('fs');
const json = require(path.join(__dirname, '../../../../', 'js', 'json'));
// WebTorrent
var WebTorrent = require('webtorrent');
const parseTorrent = require('parse-torrent');
// var client = new WebTorrent();

// Datos Json
var pck = require(path.join(__dirname, 'package.json'));
module.exports = {
  cogPage: function() {
    // Titulo Windows
    let title = document.querySelector('title');
    title.innerText = pck.info.title;
  },
  cogApp: function() {
    return pck;
  },
  update: function(file, data) {

  },
  torrent: function(tracker, data, paths) {
    // Update
    function update(file, info) {
      // load file
      const load = fs.readFileSync(file, 'utf-8');
      // json stringify
      let json = JSON.parse(load);
      // update
      for (var g = 0; g < json.length; g++) {
        if (json[g].name == info.name) {
          json[g].infoHash = info.infoHash;
          break;
        }
      }
      // save file
      fs.writeFileSync(file, JSON.stringify(json, null, 2), 'utf-8');
    }

    // Cliente
    var client = new WebTorrent();
    // Trackers
    var trackers = json.unir(tracker, data.announce);

    /* Get Uri */
    const uri = parseTorrent.toMagnetURI({
      infoHash: data.infoHash
    })

    // el Uri
    var theuri = uri + '&dn=' + data.name;

    // Download
    client.add(theuri, {
      announce: trackers,
      path: paths.folder
    }, function(torrent) {
      // create HTTP server for this torrent
      // var server = torrent.createServer()
      // server.listen('3357') // start the server listening to a port


      /*Save Progress*/
      var interval = setInterval(function() {
        // Script para agregar datos al archivo des.json
        json.awt(path.join(__dirname, 'awtorrents', data.name + '.awtorrent'), {
          infoHash: data.infoHash,
          name: data.name,
          length: data.length,
          comment: data.comment,
          info: {
            cover: data.info.cover,
            titulo: data.info.titulo,
            video: data.info.video,
            dcp: data.info.dcp
          },
          progress: (torrent.progress * 100).toFixed(1) + '%',
          received: torrent.received,
          downloadSpeed: torrent.downloadSpeed,
          uploadSpeed: torrent.uploadSpeed,
          files: data.files,
          announce: data.announce
        });

        // Update Hash
        update(path.join(__dirname, 'des.json'), {
          name: data.name,
          infoHash: data.infoHash
        });

      }, 5000)

      torrent.on('done', function() {
        // Script para agregar datos al archivo des.json
        json.news(path.join(__dirname, 'awtorrents', data.name + '.awtorrent'), {
          infoHash: data.infoHash,
          name: data.name,
          length: data.length,
          comment: data.comment,
          info: {
            cover: data.info.cover,
            titulo: data.info.titulo,
            video: data.info.video,
            dcp: data.info.dcp
          },
          progress: 100 + '%',
          received: data.length,
          downloadSpeed: 0,
          uploadSpeed: 0,
          files: data.files,
          announce: data.announce
        });

        // Clear of list of download
        json.clear(path.join(__dirname, 'des.json'), {
          id: data.name
        });
        // later, cleanup...
        // server.close()
        const t = client.get(data.infoHash);
        if (t) {
          t.destroy();
        }

        clearInterval(interval);
      })
    })


  }
}
