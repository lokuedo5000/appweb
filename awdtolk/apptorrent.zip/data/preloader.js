/*Electron JS*/
const {
  ipcRenderer,
  shell
} = require('electron');
// ID GENERATOR
const {
  v4: uuidv4
} = require('uuid');
// Default Modules
const path = require('path');
const fs = require('fs');
// Torrent Parse
const parseTorrent = require('parse-torrent');
// Modules by lokuedo5000
var script = require(path.join(__dirname, 'web'));
const json = require(path.join(__dirname, '../../../../', 'js', 'json'));
// get size
var filesize = require('file-size');

// Get Folder


// Create File Des
json.very(path.join(__dirname, 'des.json'), []);

/*Dom*/
window.addEventListener('DOMContentLoaded', () => {
  // Cog
  var ajustes = require(path.join(__dirname, 'cog', 'ajustes.json'));
  // load trackers
  var viewtrackers = document.querySelector(".viewtrackers");
  viewtrackers.innerHTML = '';
  for (var i = 0; i < ajustes.tracker.length; i++) {
    viewtrackers.innerHTML += `<div class="listtrackers">
                                ${ajustes.tracker[i]}
                              </div>`;
  }
  // Config Page
  script.cogPage();

  // Open File
  const openfile = document.querySelector(".openfile");
  openfile.addEventListener("click", function(evento) {
    // Show Loading
    showLoading();
    // Open Rutas
    ipcRenderer.send('win-file', 'AppTorrent');
  })

  // Codigo para obtener direcion y agregar datos
  ipcRenderer.on('file-open', (e, data) => {
    // verificar que la url no este vacia
    if (data == 'no_file') {
      // Hide Loading
      hideLoading();
    } else {
      // Print Url
      document.querySelector(".rutas_url_file").innerText = data;

      // /*Get Info Torrent*/
      var datos_torrent = parseTorrent(fs.readFileSync(data));
      // Verificar que no se este descargando
      // Datos Downloader
      const verySave = json.read(path.join(__dirname, 'des.json'));

      // Get lista de dsecarga
      var getData = verySave.filter(all => all.infoHash == datos_torrent.infoHash);
      // Verificar
      if (true == json.jsvery(getData)) {
        // Hide Loading
        hideLoading();
        // toast
        showtoast('Ya hay una descarga con este titulo');
        showtoast('Espera 10 segundos e intentelo de nuevo');

        // Set Update
        update(path.join(__dirname, 'des.json'), {
          name: datos_torrent.name,
          infoHash: ''
        });

        // btn add torrent
        var addNoViwe = document.querySelector(".openfile");
        addNoViwe.classList.add('d-none');

        // Espera 5 Segundos
        var espera = setInterval(function() {
          addNoViwe.classList.remove('d-none');

          // Delete time
          clearInterval(espera);
        }, 10000)

      } else {
        // Total Peso
        document.querySelector(".totaldes").innerText = filesize(datos_torrent.length).human('si');

        // Listas
        var listes = document.querySelector(".collection-list");
        listes.innerHTML = '';
        for (var i = 0; i < datos_torrent.files.length; i++) {
          var nameFile = datos_torrent.files[i].name;
          var nameExt = exts(datos_torrent.files[i].name);
          var pesoFile = filesize(datos_torrent.files[i].length).human('si');
          var icoFile = iconos(nameExt);
          listes.innerHTML += rowlist(nameFile, nameExt, pesoFile, icoFile);
        }

        // Btn play
        var btnplay = document.querySelector(".btn_run_des");
        btnplay.classList.remove('d-none');

        // Hide Loading
        hideLoading();
      }

    }

  })

  // Play Des
  const playDesTorrent = document.querySelector(".btn_run_des");
  playDesTorrent.addEventListener("click", function(evento) {
    // Show Loading
    showLoading();
    // Open Rutas
    ipcRenderer.send('win-folder', 'AppTorrent');
  })

  // Codigo para obtener direcion y agregar datos
  ipcRenderer.on('folder-open', (e, data) => {
    // Active btn Stop
    let stop_des = document.querySelector(".stop_des");
    // Active btn New
    let new_des = document.querySelector(".new_des");
    // verificar que la url no este vacia
    if (data == 'no_file') {
      // Hide Loading
      hideLoading();
    } else {
      // Print Url
      document.querySelector(".rutas_url_folder").innerText = data;
      // btn add torrent
      var addTorrent = document.querySelector(".openfile");
      addTorrent.classList.add('d-none');

      // btn Play torrent
      var playDownload = document.querySelector(".btn_run_des");
      playDownload.classList.add('d-none');

      // btn edit trackers
      var btn_edit_trackers = document.querySelector(".edit_trackers");
      btn_edit_trackers.classList.add('d-none-2');

      // ruta del archivo torrent
      let rutaFile_torrent = document.querySelector(".rutas_url_file");
      // Parse Torrent
      var awtorent = parseTorrent(fs.readFileSync(rutaFile_torrent.innerText));


      // Script para agregar datos al archivo des.json
      json.awt(path.join(__dirname, 'awtorrents', awtorent.name + '.awtorrent'), {
        infoHash: awtorent.infoHash,
        name: awtorent.name,
        length: awtorent.length,
        comment: awtorent.comment,
        info: {
          cover: 'no_info',
          titulo: 'no_info',
          video: 'no_info',
          dcp: 'no_info'
        },
        progress: '0%',
        received: 0,
        downloadSpeed: 0,
        uploadSpeed: 0,
        files: awtorent.files,
        announce: awtorent.announce
      });

      // Active btn Stop
      stop_des.classList.remove('d-none');

      // Start Download

      // Tracker
      var parse_tracker = ajustes.tracker;

      // Datos AwTorrent
      const dataInSave = json.read(path.join(__dirname, 'awtorrents', awtorent.name + '.awtorrent'));

      // Set Descarga Torrent
      script.torrent(parse_tracker, dataInSave, {
        file: rutaFile_torrent.innerText,
        folder: data
      });

      // Save Descarga
      json.add(path.join(__dirname, 'des.json'), {
        id: awtorent.name,
        name: awtorent.name,
        infoHash: awtorent.infoHash
      });

      // Script que carga cada 5 segundos los datos guardados
      var startDownload = setInterval(function() {
        // File AwTorrent
        var leerinfo = json.read(path.join(__dirname, 'awtorrents', awtorent.name + '.awtorrent'));

        // received
        document.querySelector(".received_des").innerText = filesize(leerinfo.received).human('si');

        // downloadSpeed
        document.querySelector(".dow_des").innerText = filesize(leerinfo.downloadSpeed).human('si');
        // uploadSpeed
        document.querySelector(".up_des").innerText = filesize(leerinfo.uploadSpeed).human('si');

        // Total Progreso
        var progress_app = document.querySelector(".progress_app");
        progress_app.style.width = leerinfo.progress;
        progress_app.innerText = leerinfo.progress;

        // end download
        if (leerinfo.progress == '100%') {
          // toast
          showtoast('Descarga Completa');
          // Clear btn Stop
          stop_des.classList.add('d-none');
          // Active btn New
          new_des.classList.remove('d-none');
          // Delete
          clearInterval(startDownload);
        }

      }, 5000);

      // Hide Loading
      hideLoading();

    }
  })

  // Close Win
  const closeWin = document.querySelector(".stop_des");
  closeWin.addEventListener("click", function(evento) {
    window.close();
  })

  // New Win
  const new_des_click = document.querySelector(".new_des");
  new_des_click.addEventListener("click", function(evento) {
    // Click Script
    var dataPak = script.cogApp();
    // Get Json Apps
    var apps_web = json.read(path.join(__dirname, '../../../../', 'json', 'install.json'));
    // Get app
    var getApp = apps_web.apps.filter(all => all.name == dataPak.info.title);
    // Crear Class
    var class_app = getApp[0].name.toLowerCase() + '_' + getApp[0].id;
    // Open Ventana
    ipcRenderer.send('win-new', class_app);
    // Close Win
    window.close();
  })

  // Editar Trackers
  const edit_trackers = document.querySelector(".edit_trackers");
  edit_trackers.addEventListener("click", function(evento) {
    var lostrackers = trackers(ajustes.tracker).trim();
    document.querySelector(".trackertextarea").value = lostrackers;
  })

  // Save Trackers
  const save_trackers = document.querySelector(".save_trackers");
  save_trackers.addEventListener("click", function(evento) {
    // Get Text Textarea
    var lostrackers_save = document.querySelector(".trackertextarea").value;
    // Loading
    showLoading();
    // Get Trackers
    var trackers_web = json.read(path.join(__dirname, 'cog', 'ajustes.json'));
    // Save.replace(/\s/g, ',').split(",");
    trackers_web.tracker = lostrackers_save.trim().replace(/\s/g, ',').split(",");
    fs.writeFileSync(path.join(__dirname, 'cog', 'ajustes.json'), JSON.stringify(trackers_web, null, 2), 'utf-8');
    // Reloader
    setTimeout(function() {
      location.reload();
    }, 3000);
  })

  // Get Trackers
  function trackers(data) {
    var d = "";
    for (var get in data) {
      d += `${data[get]}` + '\n';
    }
    return d;
  }


  // Rows
  function rowlist(name, ext, peso, ico) {
    return `<li class="collection-item avatar">
              <div class="circle extico">
                <div class="iconoext ${ico}"></div>
              </div>
              <span class="title">${name}</span>
              <p>Ext. - ${ext}<br>
              Peso - ${peso}</p>
              <a href="#!" class="secondary-content"><i class=""></i></a>
            </li>`;
  }

  // Get Ext
  function exts(filename) {
    return filename.slice((filename.lastIndexOf(".") - 1 >>> 0) + 2);
  }

  // iconos
  function iconos(ico) {
    if (ico == 'iso') {
      var iconoFiles = 'cwI-document-file-iso';
    } else if (ico == 'rar') {
      var iconoFiles = 'cwI-document-file-rar';
    } else if (ico == 'txt') {
      var iconoFiles = 'cwI-document-file-txt';
    } else if (ico == 'mp4') {
      var iconoFiles = 'cwI-video';
    } else if (ico == 'jpg') {
      var iconoFiles = 'cwI-image-inverted';
    } else if (ico == 'url') {
      var iconoFiles = 'cwI-link1';
    } else {
      var iconoFiles = 'cwI-plugin';
    }
    // set ico
    return iconoFiles;
  }

  // Show Loading
  function showLoading() {
    // open loading
    var loading = document.querySelector(".loading");
    loading.classList.remove('d-none');

    // active preloader
    var preloader = document.querySelector(".preloader-wrapper");
    preloader.classList.add('active');
  }

  // Hide Loading
  function hideLoading() {
    // clear loading
    var loading = document.querySelector(".loading");
    loading.classList.add('d-none');
    // clear preloader
    var preloader = document.querySelector(".preloader-wrapper");
    preloader.classList.remove('active');
  }

  // mensaje
  function showtoast(text) {
    M.toast({
      html: text
    })
  }
  // Update
  function update(file, info) {
    // load file
    const load = fs.readFileSync(file, 'utf-8');
    // json stringify
    let json = JSON.parse(load);
    // update
    for (var g = 0; g < json.length; g++) {
      if (json[g].name == info.name) {
        json[g].infoHash = info.infoHash;
        break;
      }
    }
    // save file
    fs.writeFileSync(file, JSON.stringify(json, null, 2), 'utf-8');
  }


  // // Install
  // ipcRenderer.on('app', (e, data) => {
  //   console.log(data);
  // })



});
