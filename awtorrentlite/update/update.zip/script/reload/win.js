/*Electron JS*/
const {
  ipcRenderer,
  shell
} = require('electron');
/*Modules All*/
const path = require('path');
const fs = require('fs');
const {
  v4: uuidv4
} = require('uuid');
const parseTorrent = require('parse-torrent');
var filesize = require('file-size');
// Importar Script creados por lokuedo5000
const json = require(path.join(__dirname, '../', 'lokuedo5000', 'json-files.js'));
const update = require(path.join(__dirname, '../', 'lokuedo5000', 'update.js'));

/* Rutas */
var ruta_Config = path.join(__dirname, '../../', 'data', 'cog', 'config.json');
var ruta_games = path.join(__dirname, '../../', 'data', 'public', 'db', 'games.json');

/*Dom*/
window.addEventListener('DOMContentLoaded', () => {
  /* Run Config */
  var cog_set = json.view(ruta_Config);
  if (cog_set.theme == 'vapor') {
    const body = document.querySelector('body');
    body.classList.add("no_style_theme");
  }
  /*Obtener Datos del Body*/
  const body = document.querySelector('body');
  if (body.getAttribute('data-script') == 'home') {
    filesopen();
  } else if (body.getAttribute('data-script') == 'downloading') {

    /*Desc*/
    var sort_by = (field, reverse, primer) => {

      const key = primer ?
        function(x) {
          return primer(x[field])
        } :
        function(x) {
          return x[field]
        };

      reverse = !reverse ? 1 : -1;

      return function(a, b) {
        return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
      }
    }
    /*Cargar Torrets*/
    loadtorrents();

    /* Btn Open File */
    document.querySelector('.openfile').setAttribute('href', '/');

  } else if (body.getAttribute('data-script') == 'setting') {
    /* Get Config */
    var config = json.view(ruta_Config);

    /* DB Json */
    document.querySelector('input[name=db]').value = config.db;

    /* Update */
    document.querySelector('input[name=update]').value = config.update;

    /* Port */
    document.querySelector('input[name=port]').value = config.port;

    /* Theme */
    document.querySelector('select[name=theme]').value = config.theme;

    /* Textarea Tracker */
    document.querySelector('.tx_tr').value = getTracker(config.tracker).trim();

    /* Destino */
    document.querySelector('.sl_save').value = config.save;

    /* Btn Open File */
    document.querySelector('.openfile').setAttribute('href', '/');

  } else if (body.getAttribute('data-script') == 'games') {
    var games = json.view(ruta_games);


    /* Btn Open File */
    document.querySelector('.openfile').setAttribute('href', '/');

  } else if (body.getAttribute('data-script') == 'where') {
    var games = json.view(ruta_games)

    /* Btn Open Descargar */
    const desgames = document.querySelector(".btn_des_where");
    const textDes = document.querySelector(".text_des");
    const progress_bar = document.querySelector(".btn_des_where_des");
    desgames.addEventListener("click", function(evento) {

      // Verificar si ya fue descargado en esta session
      // Para volver a descargar este juego hay que reiniciar el programa
      const leerdatos = path.join(__dirname, '../../', 'data', 'download', 'finished.json');
      let saveDes = json.read(leerdatos);
      var getVerificar = saveDes.filter(all => all.id == desgames.getAttribute('data-id'));

      if (getVerificar.length == 0) {
        /* Ruta File */
        const ruta_file_games = path.join(__dirname, '../../', 'data', 'download', 'games.json');
        let leerdata = json.read(ruta_file_games);
        if (leerdata.length > 0) {
          if (desgames.getAttribute('data-id') == leerdata[0].id) {
            // Mensaje
            toast('AppWeb: lo siento este juego ya esta en espera por favor siga los pasos para iniciar la descarga.', 'Error');
            /* Run Ads */
            let getcogApp = json.read(path.join(__dirname, '../../', 'package.json'));
            ipcRenderer.send('open-ads', 'http://adf.ly/9857561/https://lokuedo5000.github.io/appweb/awtorrentlite/?id=' + desgames.getAttribute('data-id') + '&server=' + geturl('port'));
          } else {
            // Mensaje
            toast('AppWeb: lo siento ya hay un juego en espera o se esta descargando si deseas descargar este reinicia el programa o espere a que se termine la descarga.', 'Error');
          }
        } else {
          // Esperando
          textDes.innerText = 'Esperando...';
          progress_bar.style.width = '0%';
          // Add Games of list downloads
          var getdata_uri = parseTorrent(desgames.getAttribute('data-uri'));
          // Add Tracker
          const db_announce = getdata_uri.announce;
          const total = db_announce.concat(json.view(ruta_Config).tracker);

          const add = [{
            id: desgames.getAttribute('data-id'),
            active: false,
            dn: getdata_uri.dn,
            infoHash: getdata_uri.infoHash,
            announce: uniq(total),
            progress: '0%'
          }]

          fs.writeFileSync(ruta_file_games, JSON.stringify(add, null, 2), 'utf-8');

          /* Run Ads */
          let getcogApp = json.read(path.join(__dirname, '../../', 'package.json'));
          ipcRenderer.send('open-ads', 'http://adf.ly/9857561/https://lokuedo5000.github.io/appweb/awtorrentlite/?id=' + desgames.getAttribute('data-id') + '&server=' + geturl('port'));
        }
      }else{
        toast('AppWeb: lo siento ya descargaste este juego para descargarlo de nuevo debes reiniciar el programa', 'Error');
      }

    })



    /* Set Progress */
    var timedes = setInterval(function() {
      /* Ruta File */
      const ruta_file_games = path.join(__dirname, '../../', 'data', 'download', 'games.json');
      let leerdata = json.read(ruta_file_games);

      if (leerdata.length > 0) {
        // Verificar que este en la pagina del juego agregado
        const progress_bar_run = document.querySelector(".btn_des_get");
        var getid = progress_bar_run.getAttribute('data-id');
        if (leerdata[0].id == getid) {

          // Selector del Texto del titulo de descarga
          var textselect = document.querySelector(".text_des");
          // Verificar estado de descarga
          if (leerdata[0].active == true) {
            desgames.setAttribute('disabled', 'disabled');
            textselect.innerText = 'Downloading';
            document.querySelector(".btn_des_where_des").style.width = leerdata[0].progress;

            if (leerdata[0].progress == '100%') {
              textselect.innerText = 'Finished';

              // add datos de juegos descargados
              // ruta
              var rutes = path.join(__dirname, '../../', 'data', 'download', 'finished.json');
              const addfull = json.read(rutes);

              // New Data
              const addnew = {
                id: leerdata[0].id
              }
              addfull.push(addnew);

              fs.writeFileSync(rutes, JSON.stringify(addfull, null, 2), 'utf-8');

              // limpiar json de datos de descarga
              fs.writeFileSync(ruta_file_games, JSON.stringify([], null, 2), 'utf-8');

              clearInterval(timedes);
            }

          } else if (leerdata[0].active == false) {
            textselect.innerText = 'Esperando...';
          }
        } else {
          clearInterval(timedes);
        }

      }

    }, 3000)


    /* Btn Open File */
    document.querySelector('.openfile').setAttribute('href', '/');

  }else if (body.getAttribute('data-script') == 'update') {
    /* Get Config */
    const config = json.view(ruta_Config);

    // Update Games
    update.UpdateGames(config.db);

    // Info
    var gress = document.querySelector(".progress-bar");
    var text_up = document.querySelector(".tipo_text");

    // Update Files
    const fileupdate = document.querySelector(".updatefiles");
    fileupdate.addEventListener("click", function(evento) {
      text_up.innerText = 'Actualizando Archivos';
      gress.style.width = 0 + '%';
      setTimeout(function() {
        update.UpdateFiles(config.update);
      }, 3000);

    })

    // Update Install
    const setinstall = document.querySelector(".updateinstall");
    setinstall.addEventListener("click", function(evento) {
      text_up.innerText = 'Instalando Actualizacion';
      gress.style.width = 50 + '%';
      setTimeout(function() {
        update.updateInstall();
      }, 3000);

    })
  }
  /* Enviar Ainicio */
  // function verificarlugar() {
  //   let deleteJson = document.querySelectorAll('.openfile');
  //   deleteJson.forEach(link => {
  //     link.addEventListener('click', () => {
  //       window.location.href = '/';
  //     })
  //   })
  // }

  /* Cargar Torrents agregados a descarga */
  function loadtorrents() {
    /* Verificar si Json Torrent esta vacio */
    const check = json.check(path.join(__dirname, '../../', 'data', 'download', 'addtorrent.json'));
    if (check == 0) {
      var limpiar = document.querySelector('#loadtorrent');
      limpiar.innerHTML = `<div class="infoalerta">
                            <h5>It seems that you have not selected any torrent yet</h5>
                            <h5>or</h5>
                            <h6>if you were downloading a torrent and I close the program you can download it again and start where you left off</h6>
                          </div>`;
    } else {
      var limpiar = document.querySelector('#loadtorrent');
      limpiar.innerHTML = '';
    }
    const gettorrents = json.view(path.join(__dirname, '../../', 'data', 'download', 'addtorrent.json'));

    var verbyid = gettorrents.sort(sort_by('id', true, parseInt))

    for (var i = 0; i < verbyid.length; i++) {
      if (verbyid[i].comment == undefined) {
        var comment = 'Not available';
      } else {
        var comment = verbyid[i].comment;
      }

      const uri = parseTorrent.toMagnetURI({
        infoHash: verbyid[i].infoHash
      })

      var theUri = uri + '&' + 'dn=' + verbyid[i].name + tracker(verbyid[i].announce);
      limpiar.innerHTML += `<div class="ct_des">
                              <h5 class="namegames">${verbyid[i].name}</h5>
                              <h6 class="mb-3">${comment}</h6>
                              <h6 class="mb-2 fs-6"><span class="down_id_${verbyid[i].id}">0 KB</span> / ${filesize(verbyid[i].length).human('si')}</h6>
                              <div class="progress" style="height: 5px;">
                                <div class="progress-bar pr_id_${verbyid[i].id}" role="progressbar" style="width: 0%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                              </div>
                              <!-- <div class="btn_ftr pt-3 text-end">
                                <button type="button" class="rounded btn btn-light deletejson" data-uri="${theUri}" data-hash="${verbyid[i].infoHash}">Delete</button>
                              </div> -->
                            </div>`;
    }

    setInterval(function() {
      refresh();
    }, 3000)



    /*Delete*/
    // let deleteJson = document.querySelectorAll('.deletejson');
    // deleteJson.forEach(link => {
    //   link.addEventListener('click', () => {
    //     /*Run Torrent*/
    //     ipcRenderer.send('torrent-down', {
    //       uri: 'rrr',
    //       Hash: link.getAttribute('data-hash'),
    //       tipo: 'delete'
    //     });
    //     /*Eliminar Uri*/
    //     /*Get Info Torrent*/
    //
    //     /*Eliminar Datos de Json*/
    //     var torrentsisadd = json.getTorrent(path.join(__dirname, '../../', 'data', 'download', 'addtorrent.json'));
    //
    //     for (var i = 0; i < torrentsisadd.length; i++) {
    //       if (torrentsisadd[i].infoHash == link.getAttribute('data-hash')) {
    //         torrentsisadd.splice(i, 1);
    //         break;
    //       }
    //     }
    //     fs.writeFileSync(path.join(__dirname, '../../', 'data', 'download', 'addtorrent.json'), JSON.stringify(torrentsisadd, null, 2), 'utf-8');
    //
    //     /*Reload Web*/
    //     location.reload();
    //   })
    // })


  }

  function refresh() {
    const gettorrents = json.view(path.join(__dirname, '../../', 'data', 'download', 'addtorrent.json'));
    for (var s = 0; s < gettorrents.length; s++) {
      var setpregress = document.querySelector(`.pr_id_${gettorrents[s].id}`);
      setpregress.style.width = gettorrents[s].progress;
      /*Set Peso*/
      var setpeso = document.querySelector(`.down_id_${gettorrents[s].id}`);
      setpeso.innerText = filesize(gettorrents[s].descargado).human('si');
    }
  }

  // function Open File
  function filesopen() {
    let open = document.querySelectorAll('.openfile');
    open.forEach(link => {
      link.addEventListener('click', () => {
        ipcRenderer.send('torrent-add', 'open');
        // ipcRenderer.send('torrent-ruta', 'open');
      })
    })
  }

  /*Respuestas*/
  ipcRenderer.on('ruta-torrent', (e, data) => {
    const rutaTorrent = document.querySelector('.input_set_text');
    rutaTorrent.innerText = data;

    /*Get Info Torrent*/
    var datos_torrent = parseTorrent(fs.readFileSync(data));

    const uri = parseTorrent.toMagnetURI({
      infoHash: datos_torrent.infoHash
    })
    /* Config */
    var config = json.view(ruta_Config);
    var theUri = uri + '&' + 'dn=' + datos_torrent.name + tracker(datos_torrent.announce);
    /* Convertir */

    /* Tracker Files */
    // var tr = newtr(datos_torrent.announce) + newtr(config.tracker);
    // rr(tr).trim().split(",")
    // var newp = config.tracker.push(datos_torrent.announce);
    // console.log(config.tracker);


    /*Agregar Torrent*/
    var add = json.add(path.join(__dirname, '../../', 'data', 'download', 'addtorrent.json'), {
      name: datos_torrent.name,
      infoHash: datos_torrent.infoHash,
      announce: datos_torrent.announce,
      comment: datos_torrent.comment,
      length: datos_torrent.length,
      progress: '0%',
      descargado: 0
    });


    if (add == true) {
      /*Run Torrent*/
      ipcRenderer.send('torrent-down', {
        uri: theUri,
        Hash: datos_torrent.infoHash,
        tipo: 'des'
      });
      toast('Torrent Added Successfully', 'Successful');
      // toast(theUri, 'Successful')
    } else {
      toast('sorry this torrent is already in the list', 'Error');
    }

  })


  function toast(text, tipe) {
    /* Exc Toast */
    document.querySelector('.runtoast').click();
    /* New Text */
    document.querySelector('.text_toast').innerHTML = text;
    /* New Alert */
    document.querySelector('.date_toast').innerText = tipe;
  }

  /* Action Win Minimize & Maximize => (Working) & Close*/
  let actionWin = document.querySelectorAll('.actionwin');
  actionWin.forEach(link => {
    link.addEventListener('click', () => {
      ipcRenderer.send('win-action', link.getAttribute('data-action'));
    })
  })

  /* Get Data Form */
  var formSerialize = formElement => {
    const values = {};
    const inputs = formElement.elements;

    for (let i = 0; i < inputs.length; i++) {
      values[inputs[i].name] = inputs[i].value;
    }
    return values;
  }

  /* Save Setting */
  let setting = document.querySelectorAll('.sv_setting');
  setting.forEach(link => {
    link.addEventListener('click', () => {
      var cog_in = link.getAttribute('data-cog');
      if (cog_in == 'torrent') {
        /* Get Config */
        var config = json.view(ruta_Config);

        /* Obtener Datos de Un formulario */
        var form = document.querySelector('.form_cog');
        var cog = formSerialize(form);

        cog.tracker = cog.tracker.trim().replace(/\s/g, ',').split(",");

        fs.writeFileSync(ruta_Config, JSON.stringify(cog, null, 2), 'utf-8');

      }
    })
  })



  /* Title Win */

  /* End Load */
  window.addEventListener('load', complete, false);

  function complete() {
    const title = document.querySelector('title');

    /*Set Title*/
    document.querySelector('.name_app').innerText = title.innerText;
  }

  /* Convertir ['tracker', 'Tracker'] in &tr=tracker\n <= salto de linea */
  function getTracker(text) {
    var d = "";
    var gnrs = text;
    for (var get in gnrs) {
      d += `${gnrs[get]}` + '\n';
    }
    return d;
  }

  /* Convertir ['tracker', 'Tracker'] in &tr=tracker */
  function tracker(text) {
    var gnrs = text;
    var d = "";
    for (var get in gnrs) {
      d += '&tr=' + gnrs[get];
    }
    return d;
  }

  /* New Tracker */
  function newtr(text) {
    var d = "";
    for (var get in text) {
      d += text[get] + ',';
    }
    return d;
  }

  /* Eliminar ultima Coma */
  function rr(strng) {
    var n = strng.lastIndexOf(",");
    var a = strng.substring(0, n)
    return a;
  }

  /* Obtener datos Url */
  function geturl(tipo) {
    if (tipo == 'port') {
      return new URL(window.location).port;
    }
  }

  // Filter duplicates
  function uniq(a) {
    var seen = {};
    return a.filter(function(item) {
      return seen.hasOwnProperty(item) ? false : (seen[item] = true);
    });
  }

  let urls = document.querySelectorAll('.linkapp');
  urls.forEach(link => {
    link.addEventListener('click', () => {
      event.preventDefault();
      var linkWeb = link.getAttribute("href");
      shell.openExternal(linkWeb);
    })
  })

  // document.addEventListener('click', function(event) {
  //   if (event.target.tagName === 'A' && event.target.href.startsWith('http')) {
  //     event.preventDefault()
  //     // shell.openExternal(event.target.href)
  //     if (event.target.target == "_blank") {
  //       shell.openExternal(event.target.href)
  //     } else {
  //       window.location.href = event.target.href;
  //     }
  //   }
  // })
})
